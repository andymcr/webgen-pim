<?php defined('SYSPATH') OR die('No direct script access.');

class Config extends Kohana_Config {}
