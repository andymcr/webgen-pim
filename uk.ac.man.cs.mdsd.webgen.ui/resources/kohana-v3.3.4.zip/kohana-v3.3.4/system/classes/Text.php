<?php defined('SYSPATH') OR die('No direct script access.');

class Text extends Kohana_Text {}
