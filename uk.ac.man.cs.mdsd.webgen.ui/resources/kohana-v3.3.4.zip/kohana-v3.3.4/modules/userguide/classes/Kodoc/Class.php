<?php defined('SYSPATH') or die('No direct script access.');

class Kodoc_Class extends Kohana_Kodoc_Class {}
