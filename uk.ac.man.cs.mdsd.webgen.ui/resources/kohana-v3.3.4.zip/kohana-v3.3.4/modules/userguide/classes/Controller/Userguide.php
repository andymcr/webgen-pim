<?php defined('SYSPATH') OR die('No direct script access.');

class Controller_Userguide extends Kohana_Controller_Userguide {}
